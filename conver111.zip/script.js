let save = document.querySelector(".save");

save.addEventListener("onclick",function(){
  save.innerHTML = " saved"; 
});